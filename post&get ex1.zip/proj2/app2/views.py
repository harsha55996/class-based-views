from django.shortcuts import render

def Showindex(request):
    return render(request,"index.html")
def Checkmethod(request):
    if request.method =="POST":
        mess = "I am from post"
        return render(request,"index.html",{'message1':mess})
    else:
        mess="I am from get"
        return render(request,"index.html",{'message2':mess})

